import { View, Text } from "react-native";

export default function OTPScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>OTP Screen</Text>
    </View>
  );
}